"""Studi B: AUC per lipatan rolling-origin dan sensitivitas penggabungan skor (atas saran review 8).
Pakai: python 41_auc_per_fold_studiB.py <folder kerja>
Memakai definisi fitur, model dan lipatan dari 32_bootstrap_klaster_studiB.py (bagian di atas 'rows = []').
Keluaran: hasil/studiB_auc_per_lipatan.csv (per lipatan) dan hasil/studiB_auc_penggabungan.csv (ringkasan: AUC gabungan, rata-rata antar-lipatan,
AUC dari skor peringkat dalam-lipatan)."""
import sys, warnings
import numpy as np, pandas as pd
from scipy.stats import rankdata
src = open(__file__.replace("41_auc_per_fold_studiB.py", "32_bootstrap_klaster_studiB.py"), encoding="utf8").read()
exec(src.split("rows = []; CAL = []")[0])          # root, d, WM, IX, season, models(), folds, add_anom
from sklearn.metrics import roc_auc_score
ycol = "y_next_SSJ"; hist = ["SSJ", "SSJ_l1", "SSJ_l2", "LKSJ", "LT"]; histnl = ["SSJ", "SSJ_l1", "SSJ_l2", "LT"]
sets = {"history + season": (hist + season, []), "history only": (hist, []), "history + season (no LKSJ)": (histnl + season, []), "history only (no LKSJ)": (histnl, []),
        "season only": (season, []), "monthly weather + season": (season, WM), "daily indices + season": (season, IX),
        "history + monthly weather + season": (hist + season, WM), "history + daily indices + season": (hist + season, IX)}
LAB = ["2023", "2024", "2025-2026"]; fl = folds["rolling"]; per, summ = [], []
for sname, (fixed, an) in sets.items():
    for mname in models():
        ys, ps, rk = [], [], []
        for lab, (tri, tei) in zip(LAB, fl):
            tr, te = d[tri], d[tei]; cols = fixed
            if an: tr, te = add_anom(tr, te, an); cols = fixed + [c + "_an" for c in an]
            m = models()[mname]; med = tr[cols].median(); m.fit(tr[cols].fillna(med), tr[ycol])
            p = m.predict_proba(te[cols].fillna(med))[:, 1]; y = te[ycol].values
            a = roc_auc_score(y, p) if y.min() != y.max() else np.nan
            per.append(dict(features=sname, model=mname, fold=lab, n=len(y), pos=int(y.sum()), prevalence=y.mean(), auc=a))
            ys.append(y); ps.append(p); rk.append((rankdata(p) - 0.5) / len(p))
        Y = np.concatenate(ys); pooled = roc_auc_score(Y, np.concatenate(ps)); ranked = roc_auc_score(Y, np.concatenate(rk))
        fa = [r["auc"] for r in per[-3:]]; w = [r["n"] for r in per[-3:]]
        summ.append(dict(features=sname, model=mname, pooled_auc=pooled, fold_mean_auc=np.nanmean(fa), fold_min_auc=np.nanmin(fa), fold_max_auc=np.nanmax(fa),
                         fold_weighted_auc=np.average(fa, weights=w), ranked_pooled_auc=ranked))
    print(sname, "selesai", flush=True)
P = pd.DataFrame(per); S = pd.DataFrame(summ)
P.to_csv(f"{root}/hasil/studiB_auc_per_lipatan.csv", index=False); S.to_csv(f"{root}/hasil/studiB_auc_penggabungan.csv", index=False)
pd.set_option("display.width", 250)
print(S[S.model == "LightGBM"].round(3).to_string()); print(P[P.model == "LightGBM"].pivot_table(index="features", columns="fold", values="auc").round(3).to_string())
print(P[(P.model == "LightGBM") & (P.features == "history + season")][["fold", "n", "pos", "prevalence"]].round(3).to_string())
