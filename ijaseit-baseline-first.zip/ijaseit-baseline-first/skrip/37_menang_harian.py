"""Studi A: persentase hari ketika koreksi lebih baik dari NWP mentah (sampel bersama). Pakai: python 37_menang_harian.py <data_bersih> <hasil>"""
import sys, re
src = open("skrip/35_sampel_bersama_holm.py", encoding="utf8").read()
# pakai ulang bagian awal skrip 35 sampai MAES terbentuk, ganti loop uji dengan penghitungan persentase
head = src.split("P = pickle.load")[0]
exec(head)
import pickle
P = pickle.load(open(f"{out}/_pred.pkl", "rb"))
res = {}
for site, (fn, ft) in SITES.items():
    tr_ = pd.read_csv(f"{dd}/{ft}", parse_dates=["time"]).set_index("time").sort_index(); nw = daily_nwp(f"{dd}/{fn}"); D = nw.join(tr_[[c for _, c, _ in V.values()]], how="inner")
    for L in LEADS:
        T = pd.DataFrame({k: D[V[k][1]] for k in V}); N = pd.DataFrame({k: D[f"{k}_n{L}"] for k in V}); R = (T - N)[TV]
        feat = pd.concat([T[TV], np.log1p(T[["hujan"]].clip(lower=0)), R.add_suffix("_res")], axis=1); fv = feat.values; idx = D.index; N_ = len(idx); ok = np.zeros(N_, bool)
        for i in range(N_):
            e = i - L
            if e - WIN_DAYS + 1 < 0: continue
            w = fv[e - WIN_DAYS + 1: e + 1]; z = [N.suhu.iloc[i], N.rh.iloc[i], N.angin.iloc[i], N.hujan.iloc[i]]; y = R.iloc[i].values
            ok[i] = not (np.isnan(w).any() or np.isnan(z).any() or np.isnan(y).any())
        for k in TV:
            dates, yt, M = P[(site, k, L)]; pos = idx.get_indexer(pd.DatetimeIndex(dates)); sel = np.flatnonzero(ok[pos]); y = yt[sel]
            e0 = np.abs(y - np.asarray(M["NWP mentah"])[sel]); eb = np.abs(y - np.asarray(M["Bias bergulir 30 hari"])[sel]); er = np.abs(y - np.asarray(M["Ridge walk-forward"])[sel])
            res[(site, k, L)] = (len(sel), (eb < e0).mean(), (er < e0).mean(), np.median(y - np.asarray(M["NWP mentah"])[sel]), np.median(y - np.asarray(M["Bias bergulir 30 hari"])[sel]), np.median(y - np.asarray(M["Ridge walk-forward"])[sel]), np.std(y - np.asarray(M["NWP mentah"])[sel]), np.std(y - np.asarray(M["Ridge walk-forward"])[sel]))
for k, v in res.items(): print(k, [round(float(x), 3) for x in v])
