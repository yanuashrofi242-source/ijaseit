"""Diagnosis galat sistematis ECMWF dan pengaruh panjang jendela latih: autokorelasi galat mentah, dan skill Ridge/bias bergulir menurut panjang jendela.
Pakai: python 36_diagnosis_galat_dan_jendela.py <data_bersih> <hasil>   (sampel bersama = hari yang sama seperti 35_sampel_bersama_holm.py)"""
import sys, pickle, warnings, numpy as np, pandas as pd
warnings.filterwarnings("ignore")
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
dd, out = sys.argv[1], sys.argv[2]
exec(open(__file__.replace("36_diagnosis_galat_dan_jendela.py", "31_simpan_deret_konformal.py")).read().split("OUT = {}")[0].replace("dd, out = sys.argv[1], sys.argv[2]", ""))
T_TE = "2025-07-01"; rows = []; ac = []
for site, (fn, ft) in SITES.items():
    tr_ = pd.read_csv(f"{dd}/{ft}", parse_dates=["time"]).set_index("time").sort_index(); nw = daily_nwp(f"{dd}/{fn}")
    D = nw.join(tr_[[c for _, c, _ in V.values()]], how="inner"); doys = D.index.dayofyear
    for k in ("suhu", "rh", "angin"):
        c = V[k][1]; y_all = D[c]
        for L in LEADS:
            F = pd.DataFrame(index=D.index); F["nwp"] = D[f"{k}_n{L}"]
            for kk, (_, cc, _) in V.items():
                F[f"{kk}_obs"] = D[cc].shift(L); F[f"{kk}_obs7"] = D[cc].rolling(7).mean().shift(L); F[f"{kk}_nwp"] = D[f"{kk}_n{L}"]
            F["doy_s"] = np.sin(2 * np.pi * doys / 365.25); F["doy_c"] = np.cos(2 * np.pi * doys / 365.25)
            res = F.nwp - y_all; F["bias30"] = res.rolling(30, min_periods=15).mean().shift(L)
            ok = F.notna().all(axis=1) & y_all.notna(); te = ok & (D.index >= T_TE)
            e = res[te]; ac.append(dict(site=site, var=k, L=L, r1=e.autocorr(1), r7=e.autocorr(7), r30=e.autocorr(30), mean_err=e.mean(), sd_err=e.std(), share_mean=e.mean() ** 2 / (e ** 2).mean()))
            mae0 = np.abs(res[te]).mean()
            for w in (7, 14, 30, 60, 90):
                b = res.rolling(w, min_periods=max(5, w // 2)).mean().shift(L); m_ = te & b.notna(); rows.append(dict(site=site, var=k, L=L, method="rolling bias", window=w, skill=1 - np.abs(y_all[m_] - (F.nwp[m_] - b[m_])).mean() / np.abs(res[m_]).mean()))
            for WIN in (60, 120, 240, 365, 540):
                pr = pd.Series(np.nan, index=F.index)
                for s0 in pd.date_range("2025-03-01", D.index.max(), freq="30D"):
                    blk = ok & (D.index >= s0) & (D.index < s0 + pd.Timedelta(days=30)); cut = s0 - pd.Timedelta(days=L); trw = ok & (D.index <= cut) & (D.index > cut - pd.Timedelta(days=WIN))
                    if blk.sum() == 0 or trw.sum() < min(60, WIN // 2): continue
                    pr[blk] = make_pipeline(StandardScaler(), Ridge(10.0)).fit(F[trw], y_all[trw]).predict(F[blk])
                m_ = te & pr.notna(); rows.append(dict(site=site, var=k, L=L, method="Ridge", window=WIN, skill=1 - np.abs(y_all[m_] - pr[m_]).mean() / np.abs(res[m_]).mean()))
R = pd.DataFrame(rows); A = pd.DataFrame(ac); R.to_csv(f"{out}/studiA_sensitivitas_jendela.csv", index=False); A.to_csv(f"{out}/studiA_autokorelasi_galat.csv", index=False)
pd.set_option("display.width", 200)
print(R.groupby(["method", "window"]).skill.mean().mul(100).round(1)); print(R.groupby(["method", "window"]).skill.apply(lambda s: s.count()))
print(A.groupby("var")[["r1", "r7", "r30", "share_mean"]].mean().round(2)); print(A.groupby("L")[["r1", "r7", "share_mean"]].mean().round(2)); print(A.groupby("site")[["mean_err", "sd_err", "share_mean"]].mean().round(2))
print(A.round(2).to_string())
