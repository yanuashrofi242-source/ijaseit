"""Studi B: AUC rata-rata antar-lipatan sebagai ukuran utama, dengan bootstrap klaster desa (atas saran review 9).
Pakai: python 42_auc_rata_lipatan_bootstrap_studiB.py <folder kerja>
Definisi fitur, model dan lipatan sama dengan 41_auc_per_fold_studiB.py. Tiap replikasi menarik desa dengan pengembalian (semua baris desa ikut),
menghitung AUC dalam tiap lipatan (lipatan satu kelas dilewati), lalu merata-ratakannya; selisih terhadap 'history + season' dan terhadap 'season only' dihitung pada tarikan yang sama.
Keluaran: hasil/studiB_auc_rata_lipatan_bootstrap.csv."""
import sys, warnings
import numpy as np, pandas as pd
src = open(__file__.replace("42_auc_rata_lipatan_bootstrap_studiB.py", "32_bootstrap_klaster_studiB.py"), encoding="utf8").read()
exec(src.split("rows = []; CAL = []")[0])          # root, d, WM, IX, season, models(), folds, add_anom
from sklearn.metrics import roc_auc_score
ycol = "y_next_SSJ"; hist = ["SSJ", "SSJ_l1", "SSJ_l2", "LKSJ", "LT"]; histnl = ["SSJ", "SSJ_l1", "SSJ_l2", "LT"]
sets = {"history + season": (hist + season, []), "history only": (hist, []), "history + season (no LKSJ)": (histnl + season, []), "history only (no LKSJ)": (histnl, []),
        "season only": (season, []), "monthly weather + season": (season, WM), "daily indices + season": (season, IX),
        "history + monthly weather + season": (hist + season, WM), "history + daily indices + season": (hist + season, IX)}
fl = folds["rolling"]; B = 1000; rng = np.random.default_rng(0)
vil = [d.loc[tei, "Desa"].values for _, tei in fl]; U = sorted(d.Desa.unique())
draws = [rng.choice(len(U), len(U)) for _ in range(B)]           # tarikan desa yang sama dipakai semua model dan fitur
def fold_mean(Y, P, V, pick):
    out = []
    for y, p, v in zip(Y, P, V):
        s = np.concatenate([np.where(v == U[j])[0] for j in pick])
        if len(s) and y[s].min() != y[s].max(): out.append(roc_auc_score(y[s], p[s]))
    return np.mean(out) if out else np.nan
rows = []
for mname in models():
    store = {}
    for sname, (fixed, an) in sets.items():
        Y, P = [], []
        for tri, tei in fl:
            tr, te = d[tri], d[tei]; cols = fixed
            if an: tr, te = add_anom(tr, te, an); cols = fixed + [c + "_an" for c in an]
            m = models()[mname]; med = tr[cols].median(); m.fit(tr[cols].fillna(med), tr[ycol])
            P.append(m.predict_proba(te[cols].fillna(med))[:, 1]); Y.append(te[ycol].values)
        store[sname] = (Y, P)
    Y0, P0 = store["history + season"]
    base_b = np.array([fold_mean(Y0, P0, vil, pk) for pk in draws])
    Ys, Ps = store["season only"]; seas_b = np.array([fold_mean(Ys, Ps, vil, pk) for pk in draws]); est_s = fold_mean(Ys, Ps, vil, np.arange(len(U)))
    for sname, (Y, P) in store.items():
        est = fold_mean(Y, P, vil, np.arange(len(U))); b = np.array([fold_mean(Y, P, vil, pk) for pk in draws])
        est0 = fold_mean(Y0, P0, vil, np.arange(len(U))); dd = b - base_b; dd = dd[~np.isnan(dd)]; bb = b[~np.isnan(b)]; ds = b - seas_b; ds = ds[~np.isnan(ds)]
        rows.append(dict(features=sname, model=mname, fold_mean_auc=est, ci_lo=np.percentile(bb, 2.5), ci_hi=np.percentile(bb, 97.5),
                         diff_vs_hist_season=est - est0, diff_lo=np.percentile(dd, 2.5) if len(dd) else np.nan, diff_hi=np.percentile(dd, 97.5) if len(dd) else np.nan,
                         diff_vs_season=est - est_s, dseas_lo=np.percentile(ds, 2.5), dseas_hi=np.percentile(ds, 97.5)))
    print(mname, "selesai", flush=True)
# persistence: score = 1 if attack in the current month (SSJ > 0); no model, so no model-dependent entry
Yp = [d.loc[tei, ycol].values for _, tei in fl]; Pp = [(d.loc[tei, "SSJ"] > 0).astype(float).values for _, tei in fl]
est = fold_mean(Yp, Pp, vil, np.arange(len(U))); b = np.array([fold_mean(Yp, Pp, vil, pk) for pk in draws]); b = b[~np.isnan(b)]
rows.append(dict(features="persistence", model="-", fold_mean_auc=est, ci_lo=np.percentile(b, 2.5), ci_hi=np.percentile(b, 97.5)))
R = pd.DataFrame(rows); R.to_csv(f"{root}/hasil/studiB_auc_rata_lipatan_bootstrap.csv", index=False)
pd.set_option("display.width", 250); print(R.round(3).to_string())
