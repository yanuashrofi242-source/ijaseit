import os
ROOT=os.environ.get("KERJA", os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")))
HASIL=ROOT+"/hasil/"; DATA=ROOT+"/data_bersih"; SKRIP=os.path.dirname(os.path.abspath(__file__)); GAMBAR=ROOT+"/gambar"; os.makedirs(GAMBAR,exist_ok=True)
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
fam="DejaVu Serif"
for f in ["Times New Roman","Liberation Serif","Nimbus Roman"]:
    if any(f in x.name for x in fm.fontManager.ttflist): fam=f; break
plt.rcParams.update({"font.family":fam,"font.size":7,"axes.linewidth":0.6,"axes.spines.top":False,"axes.spines.right":False,"axes.titlesize":7.5,"axes.labelsize":7,"xtick.labelsize":6.5,"ytick.labelsize":6.5,"legend.fontsize":6,"lines.linewidth":1.0,"xtick.major.width":0.5,"ytick.major.width":0.5})
C={"raw":"#7A8794","pers":"#000000","bias":"#2E7D5B","ridge":"#14284A","lgbm":"#8A5A00","gru":"#C0392B","nb64":"#8E44AD","nb16":"#D68910"}
