"""Studi A: sensitivitas uji berpasangan terhadap autokorelasi selisih galat (atas saran review 8).
Pakai: python 40_sensitivitas_dm.py <data_bersih> <hasil>
Butuh: hasil/_pred.pkl (15), hasil/_pred_bigru.pkl (16s), hasil/_pred_nbeats.pkl (17, 64 unit), hasil/_pred_nbeats_kecil.pkl (17 dengan NB_HID=16 NB_WD=0.01 NB_EPOCHS=25 NB_TAG=_kecil).
Tiga p-value per sel dan per perbandingan, semuanya pada hari bersama dan galat mutlak:
  (a) DM-HLN dengan autokovarians sampai lag h-1 (h = lead), seperti Tabel VI naskah;
  (b) DM dengan varians HAC (bobot Bartlett, 7 lag) dan distribusi t(n-1);
  (c) bootstrap blok bergerak berpasangan (blok 14 hari, 5.000 ulangan, selisih rata-rata dipusatkan).
Koreksi Holm di dalam tiap keluarga 18 sel."""
import sys, pickle, numpy as np, pandas as pd
from scipy import stats
out = sys.argv[2]
def d_series(e1, e2): return np.abs(e1) - np.abs(e2)
def p_dm(d, bw):
    n = len(d); x = d - d.mean(); s = (x ** 2).mean()
    for k in range(1, bw + 1): s += 2 * (1 - k / (bw + 1)) * (x[k:] * x[:-k]).mean()
    return 2 * (1 - stats.t.cdf(abs(d.mean() / np.sqrt(max(s, 1e-12) / n)), df=n - 1))
def p_hln(d, h):
    n = len(d); x = d - d.mean(); s = (x ** 2).mean()
    for k in range(1, max(h, 1)): s += 2 * (1 - k / max(h, 1)) * (x[k:] * x[:-k]).mean()
    st = d.mean() / np.sqrt(max(s, 1e-12) / n) * np.sqrt((n + 1 - 2 * h + h * (h - 1) / n) / n)
    return 2 * (1 - stats.t.cdf(abs(st), df=n - 1))
rng = np.random.default_rng(0)
def p_block(d, L=14, B=5000):
    n = len(d); nb = int(np.ceil(n / L)); x = d - d.mean(); obs = abs(d.mean()); starts = rng.integers(0, n - L + 1, (B, nb))
    m = np.array([np.concatenate([x[s:s + L] for s in st])[:n].mean() for st in starts])
    return (1 + np.sum(np.abs(m) >= obs)) / (B + 1)
def holm(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for r, i in enumerate(o): run = max(run, (m - r) * p[i]); adj[i] = min(1, run)
    return adj
P = pickle.load(open(f"{out}/_pred.pkl", "rb")); GRU = pickle.load(open(f"{out}/_pred_bigru.pkl", "rb"))
NB64 = pickle.load(open(f"{out}/_pred_nbeats.pkl", "rb")); NB16 = pickle.load(open(f"{out}/_pred_nbeats_kecil.pkl", "rb"))
rows = []
for key, (dates, ynn_dates_pred) in GRU.items():
    site, k, L = key; bd, yt, M = P[key]; bd = pd.DatetimeIndex(bd); nd = pd.DatetimeIndex(dates)
    pos = bd.get_indexer(nd); assert (pos >= 0).all(); y = np.asarray(yt)[pos]; Mm = {m: np.asarray(v)[pos] for m, v in M.items()}
    Mm["BiGRU"] = np.asarray(ynn_dates_pred)
    for nm, D_ in (("N-BEATS-64", NB64), ("N-BEATS-16", NB16)):
        dd_, pp_ = D_[key]; assert (pd.DatetimeIndex(dd_) == nd).all(); Mm[nm] = np.asarray(pp_)
    for fam, a, b in (("Ridge vs rolling bias", "Ridge walk-forward", "Bias bergulir 30 hari"), ("Ridge vs raw NWP", "Ridge walk-forward", "NWP mentah"), ("Rolling bias vs raw NWP", "Bias bergulir 30 hari", "NWP mentah"),
                      ("Ridge vs persistence", "Ridge walk-forward", "Persistensi"), ("LightGBM vs rolling bias", "LightGBM residu walk-forward", "Bias bergulir 30 hari"),
                      ("BiGRU vs Ridge", "BiGRU", "Ridge walk-forward"), ("BiGRU vs rolling bias", "BiGRU", "Bias bergulir 30 hari"),
                      ("N-BEATS-64 vs Ridge", "N-BEATS-64", "Ridge walk-forward"), ("N-BEATS-16 vs Ridge", "N-BEATS-16", "Ridge walk-forward")):
        d = d_series(y - Mm[a], y - Mm[b])
        r1 = np.corrcoef(d[1:], d[:-1])[0, 1]
        rows.append(dict(family=fam, site=site, var=k, L=L, n=len(y), d=d.mean(), lag1_d=r1, p_hln=p_hln(d, L), p_hac7=p_dm(d, 7), p_block14=p_block(d)))
R = pd.DataFrame(rows)
for c in ("p_hln", "p_hac7", "p_block14"):
    R[c + "_holm"] = np.nan
    for f, g in R.groupby("family", sort=False): R.loc[g.index, c + "_holm"] = holm(g[c].values)
R.to_csv(f"{out}/studiA_sensitivitas_dm.csv", index=False)
S = []
for f, g in R.groupby("family", sort=False):
    r = dict(family=f, cells=len(g), better=int((g.d < 0).sum()), mean_lag1_d=g.lag1_d.mean())
    for c in ("p_hln", "p_hac7", "p_block14"):
        r[c + "_raw_better_worse"] = f"{int(((g[c] < .05) & (g.d < 0)).sum())}/{int(((g[c] < .05) & (g.d > 0)).sum())}"
        r[c + "_holm_better_worse"] = f"{int(((g[c + '_holm'] < .05) & (g.d < 0)).sum())}/{int(((g[c + '_holm'] < .05) & (g.d > 0)).sum())}"
    S.append(r)
S = pd.DataFrame(S); S.to_csv(f"{out}/studiA_sensitivitas_dm_ringkasan.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30); print(S.round(3).to_string())
